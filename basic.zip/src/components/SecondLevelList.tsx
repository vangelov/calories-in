import { Box, Input, Button } from '@chakra-ui/react'
import { useFieldArray, useFormContext, useWatch } from 'react-hook-form'

type Props = {
  index: number
}

function Test({ index }: { index: number }) {
  const t = useWatch({ name: `test.${index}.nestedArray` })
  console.log('t2', t)
  return null
}
function SecondLevelList({ index }: Props) {
  const { register, getValues, control } = useFormContext()
  const { fields } = useFieldArray({
    name: `test.${index}.nestedArray`,
  })

  console.log('f2', fields)
  return (
    <div>
      <Test index={index} />
      {fields.map((field: any, index2) => (
        <div key={field.id}>
          <input
            {...register(`test.${index}.nestedArray[${index2}].field1`)}
            defaultValue={field.amountInGrams}
          />
        </div>
      ))}
    </div>
  )
}

export default SecondLevelList
