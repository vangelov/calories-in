import { Box } from '@chakra-ui/layout'
import { useFieldArray, FormProvider, useForm, useWatch } from 'react-hook-form'
import SecondLavelList from './SecondLevelList'

const defaultValues = {
  test: [
    {
      name: 'useFieldArray1',
      nestedArray: [{ field1: 'field1', field2: 'field2' }],
    },
    {
      name: 'useFieldArray2',
      nestedArray: [{ field1: 'field1', field2: 'field2' }],
    },
    {
      name: 'useFieldArray3',
      nestedArray: [{ field1: 'field1', field2: 'field2' }],
    },
  ],
}

function Fuck() {
  const t = useWatch({})
  console.log('fsfds', t)
  return null
}

function FirstLevelList() {
  const methods2 = useForm({ defaultValues })
  const { fields, remove } = useFieldArray({
    name: 'test',
    control: methods2.control,
  })

  console.log('fields', fields)

  return (
    <FormProvider {...methods2}>
      <Fuck />
      <Box>
        {fields.map((field, index) => {
          return (
            <div>
              <button onClick={() => remove(index)}>Remove</button>
              <SecondLavelList key={field.id} index={index} />
            </div>
          )
        })}
      </Box>
    </FormProvider>
  )
}

export default FirstLevelList
