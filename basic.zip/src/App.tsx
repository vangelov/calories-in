import { extendTheme } from '@chakra-ui/react'
import 'focus-visible/dist/focus-visible'
import FirstLevelList from 'components/FirstLevelList'

// 2. Call `extendTheme` and pass your custom values
const theme = extendTheme({
  styles: {
    global: {
      html: {
        overflow: 'hidden',
      },
      '.js-focus-visible :focus:not([data-focus-visible-added])': {
        outline: 'none',
        'box-shadow:': 'none',
      },
    },
  },
})
function App() {
  return <FirstLevelList />
}

export default App
