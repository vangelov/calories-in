type Stats = {
  protein: number
}

export type { Stats }
