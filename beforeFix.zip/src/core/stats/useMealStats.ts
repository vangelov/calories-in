import { useFormContext, useWatch } from 'react-hook-form'
import {
  IngredientField,
  MealField,
  getIngredinetsFormsPath,
  IngredientForm,
} from 'core/dietForm'
import { Stats } from './types'
import { sumStats } from './utils'
import { useState } from 'react'

function useMealStats(ingredientsForms: IngredientForm[]) {
  const { getValues } = useFormContext()

  const ingredientsStats: Stats[] = ingredientsForms.map(
    (ingredientForm, index) => {
      return { protein: Number(ingredientForm.amountInGrams) * 2 }
    }
  )

  const mealStats = sumStats(ingredientsStats)

  function onFormsChange(forms: IngredientForm[]) {
    console.log('t', getValues())
  }

  return {
    ingredientsStats,
    mealStats,
    onFormsChange,
  }
}

export default useMealStats
