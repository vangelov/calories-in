import { Box, Input, Button } from '@chakra-ui/react'
import { useFieldArray, useFormContext, Controller } from 'react-hook-form'

type Props = {
  index: number
}
function SecondLevelList({ index }: Props) {
  const { register, getValues, control } = useFormContext()
  const { fields } = useFieldArray({
    name: `mealsForms[${index}].ingredientsForms`,
  })

  function onChange() {
    console.log('change', getValues())
  }
  console.log('f2', fields)
  return (
    <div>
      {fields.map((field, index2) => (
        <div key={field.id}>
          <input
            name={`mealsForms[${index}].ingredientsForms[${index2}].amountInGrams`}
            ref={register()}
            defaultValue={field.amountInGrams}
            onChange={onChange}
          />
        </div>
      ))}
    </div>
  )
}

export default SecondLevelList
