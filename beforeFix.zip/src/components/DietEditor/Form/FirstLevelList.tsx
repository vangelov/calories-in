import { Box } from '@chakra-ui/layout'
import { useFieldArray } from 'react-hook-form'
import SecondLavelList from './SecondLevelList'

function FirstLevelList() {
  const { fields, remove } = useFieldArray({
    name: 'mealsForms',
  })

  console.log('fields', fields)

  return (
    <Box>
      {fields.map((field, index) => {
        return (
          <div>
            <button onClick={() => remove(index)}>Remove</button>
            <SecondLavelList key={field.id} index={index} />
          </div>
        )
      })}
    </Box>
  )
}

export default FirstLevelList
