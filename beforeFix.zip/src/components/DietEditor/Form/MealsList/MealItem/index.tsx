import {
  DietForm,
  getMealsFormsPath,
  IngredientForm,
  MealField,
} from 'core/dietForm'
import { Flex, LayoutProps, SpaceProps, Input } from '@chakra-ui/react'
import IngredientsList from './IngredientsList'
import { useMealStats, useUpdateMealStats } from 'core/stats'
import useIngredientsController from './useIngredientsController'
import Header from './Header'
import { useFormContext } from 'react-hook-form'
import { ForwardedRef, forwardRef, useEffect } from 'react'

type Props = {
  mealField: MealField
  index: number
  forwardRef?: ForwardedRef<HTMLDivElement>
  onRemove: (index: number) => void
  autoFocusName: boolean
} & LayoutProps &
  SpaceProps

function MealItem({
  mealField,
  index,
  onRemove,
  forwardRef,
  autoFocusName,
  ...rest
}: Props) {
  const { getValues } = useFormContext<DietForm>()
  const ingredientsFormsController = useIngredientsController(index, mealField)
  const { mealStats, ingredientsStats, onFormsChange } = useMealStats(
    ingredientsFormsController.ingredientsFields as IngredientForm[]
  )
  const { register } = useFormContext()
  useUpdateMealStats(index, mealStats)

  function onChange() {
    console.log('change', getValues())
    const form = getValues()
    onFormsChange(form.mealsForms[index].ingredientsForms)
  }

  return (
    <Flex
      ref={forwardRef}
      flexDirection="column"
      backgroundColor="gray"
      {...rest}
    >
      <Input
        type="hidden"
        name={getMealsFormsPath(index, 'fieldId')}
        ref={node => register(node)}
        defaultValue={mealField.fieldId}
      />
      <Header
        zIndex={1}
        mealIndex={index}
        mealField={mealField}
        onRemove={onRemove}
        autoFocusName={autoFocusName}
        onChange={onChange}
      />

      <IngredientsList
        mealField={mealField}
        mealIndex={index}
        ingredientsFields={ingredientsFormsController.ingredientsFields}
        ingredientsStats={ingredientsStats}
        onIngredientRemove={ingredientsFormsController.onIngredientRemove}
        onChange={() => {}}
      />
    </Flex>
  )
}

export default forwardRef<HTMLDivElement, Props>((props, ref) => (
  <MealItem forwardRef={ref} {...props} />
))
