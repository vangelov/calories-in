import { getMealForm, MealField, useMealsForms } from 'core/dietForm'
import { useUndoRedoMethods } from 'core/undoRedo'
import { RefObject, useEffect, useState } from 'react'
import { useFormContext } from 'react-hook-form'

type UseMealsControllerParams = {
  getMealItemRefById: (id: string) => RefObject<HTMLDivElement>
}

type MealsController = {
  mealsFields: MealField[]
  onMealAdd: () => void
  onMealRemove: (index: number) => void
}

function useMealsController({
  getMealItemRefById,
}: UseMealsControllerParams): MealsController {
  const { control } = useFormContext()
  const { mealsFields, appendMealForm, removeMealForm } = useMealsForms({
    control,
  })
  const { saveLastChange } = useUndoRedoMethods()
  const [
    pendingScrollMealItemId,
    setPendingScrollMealItemId,
  ] = useState<string>()

  useEffect(() => {
    if (pendingScrollMealItemId) {
      const ref = getMealItemRefById(pendingScrollMealItemId)

      if (ref.current) {
        ref.current.scrollIntoView({
          behavior: 'smooth',
          block: 'start',
        })
      }
    }
  }, [pendingScrollMealItemId, getMealItemRefById])

  function onMealAdd() {
    const mealForm = getMealForm()
    appendMealForm(mealForm)
    saveLastChange()
    setPendingScrollMealItemId(mealForm.fieldId)
  }

  function onMealRemove(index: number) {
    removeMealForm(index)
  }

  return {
    mealsFields,
    onMealAdd,
    onMealRemove,
  }
}

export type { MealsController }

export default useMealsController
