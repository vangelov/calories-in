import { Box } from '@chakra-ui/react'
import MealItem from './MealItem'
import useMealsController, { MealsController } from './useMealsController'
import { MutableRefObject, RefObject } from 'react'
import useIsFirstRender from 'core/utils/useIsFirstRender'

type Props = {
  mealsControllerRef: MutableRefObject<MealsController | undefined>
  getMealItemRefById: (id: string) => RefObject<HTMLDivElement>
}

function MealsList({ mealsControllerRef, getMealItemRefById }: Props) {
  const mealsController = useMealsController({ getMealItemRefById })
  const isFirstRender = useIsFirstRender()

  mealsControllerRef.current = mealsController

  console.log('render')

  return (
    <Box height="100%">
      {mealsController.mealsFields.map((mealField, index) => (
        <MealItem
          key={mealField.fieldId}
          ref={getMealItemRefById(mealField.fieldId as string)}
          index={index}
          onRemove={mealsController.onMealRemove}
          mealField={mealField}
          autoFocusName={!isFirstRender}
        />
      ))}
    </Box>
  )
}

export * from './useMealsController'

export default MealsList
